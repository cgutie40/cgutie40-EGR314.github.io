# Derived from: 
# * https://github.com/peterhinch/micropython-async/blob/master/v3/as_demos/auart.py
# * https://github.com/tve/mqboard/blob/master/mqtt_async/hello-world.py
# * https://github.com/peterhinch/micropython-mqtt
# * https://github.com/embedded-systems-design/external_pycopy-lib


import ssl

from mqtt_as.mqtt_as import MQTTClient
from mqtt_as.mqtt_local import wifi_led, blue_led, config
import uasyncio as asyncio
from machine import UART
from machine import Pin
import time
from config import *


MAXTX = 4

blue_led = Pin(9, Pin.OUT)
red_led = Pin(5, Pin.OUT)    
hb_led = Pin(10, Pin.OUT)

button = Pin(4, Pin.IN)

uart = UART(2, 9600,tx=35,rx=36)
uart.init(9600, bits=8, parity=None, stop=1,flow=0) # init with given parameters

async def receiver():
    b = b''
    sreader = asyncio.StreamReader(uart)
    while True:
        res = await sreader.read(1)
        if res==b';':
            b+=res
            await client.publish(TOPIC_PUB, b, qos=1)

            print('published', b)
            b = b''
        else:
            b+=res

# Subscription callback
def sub_cb(topic, msg, retained):
    message = msg.decode().strip()

    print(f'Topic: "{topic.decode()}" Message: "{message}" Retained: {retained}')

    if message == "BT;":
        blue_led.on()
        print("Blue LED ON")

    elif message == "BT OFF;":
        blue_led.off()
        print("Blue LED OFF")

    elif message == "DB;":
        red_led.on()
        print("Red LED ON")

    elif message == "DB OFF;":
        red_led.off()
        print("Red LED OFF")

    uart.write(msg)


# Demonstrate scheduler is operational.
async def heartbeat():
    s = True
    while True:
        await asyncio.sleep_ms(500)
        hb_led.value(s)
        s = not s

async def wifi_han(state):
    wifi_led(not state)
    print('Wifi is ', 'up' if state else 'down')
    await asyncio.sleep(1)

# If you connect with clean_session True, must re-subscribe (MQTT spec 3.1.2.4)
async def conn_han(client):
    await client.subscribe(TOPIC_SUB, 1)

async def main(client):
    try:
        await client.connect()
    except OSError as e:
        import sys
        print('Connection failed:', e)
        sys.print_exception(e)
        return
    asyncio.create_task(receiver())
    asyncio.create_task(button_task()) 

    n = 0
    while True:
        await asyncio.sleep(5)
        print('publish', n)
        # If WiFi is down the following will pause for the duration.
        await client.publish(TOPIC_HB, '{} {}'.format(n, client.REPUB_COUNT), qos = 1)
        n += 1

# Button Task
async def button_task():
    last = button.value()
    press_time = 0

    while True:
        cur = button.value()

        # Button pressed
        if last == 1 and cur == 0:
            press_time = time.ticks_ms()

        # Button released
        if last == 0 and cur == 1:
            duration = time.ticks_diff(time.ticks_ms(), press_time)

            if duration > 1000:  # longer than 1 second
                print("Button HOLD")
                await client.publish(TOPIC_PUB, b'BUTTON_HOLD;', qos=1)
            else:
                print("Button pressed!")
                await client.publish(TOPIC_PUB, b'BUTTON;', qos=1)

        last = cur
        await asyncio.sleep_ms(50)

# Define configuration

config['server'] = MQTT_SERVER
config['ssid']     = WIFI_SSID
config['wifi_pw']  = WIFI_PASSWORD

config['ssl']  = True
# read in DER formatted certs & user key
with open('certs/student_key.pem', 'rb') as f:
    key_data = f.read()
with open('certs/student_crt.pem', 'rb') as f:
    cert_data = f.read()
with open('certs/ca_crt.pem', 'rb') as f:
    ca_data = f.read()
ssl_params = {}
ssl_params["cert"] = cert_data
ssl_params["key"] = key_data
ssl_params["cadata"] = ca_data
ssl_params["server_hostname"] = MQTT_SERVER
ssl_params["cert_reqs"] = ssl.CERT_REQUIRED
config["time_server"] = MQTT_SERVER
config["time_server_timeout"] = 10

config['ssl_params']  = ssl_params

config['subs_cb'] = sub_cb
config['wifi_coro'] = wifi_han
config['connect_coro'] = conn_han
config['clean'] = True
config['user'] = MQTT_USER
config["password"] = MQTT_PASSWORD

# Set up client
MQTTClient.DEBUG = True  # Optional
client = MQTTClient(config)

asyncio.create_task(heartbeat())
try:
    asyncio.run(main(client))
finally:
    client.close()  # Prevent LmacRxBlk:1 errors
    asyncio.new_event_loop()